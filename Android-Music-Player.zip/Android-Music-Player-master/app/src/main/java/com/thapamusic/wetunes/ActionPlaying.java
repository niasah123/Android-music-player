package com.thapamusic.wetunes;

public interface ActionPlaying {
    void playPauseBtnClicked();
    void prevBtnClicked();
    void nextBtnClicked();
}
